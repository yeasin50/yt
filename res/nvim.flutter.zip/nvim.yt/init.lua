
vim.g.maplocalleader = " "
vim.g.mapleader = " "

require("config.lazy")
require("config.keymap")

vim.opt.clipboard:append("unnamedplus")
vim.opt.numberwidth = 2
vim.opt.signcolumn = "yes"
vim.o.number = true
vim.o.relativenumber = true

vim.o.mouse = "a"

vim.opt.wrap = true

vim.opt.spell = true
vim.opt.spelllang = { "en_us" }

local o = vim.o


o.expandtab = true -- expand tab input with spaces characters
o.smartindent = true -- syntax aware indentations for newline inserts
o.tabstop = 2 -- num of space characters per tab
o.shiftwidth = 2 -- spaces per indentation level
-- Disable F1 key in normal, insert, and visual mode
vim.api.nvim_set_keymap("n", "<F1>", "<Nop>", { noremap = true, silent = true })
vim.api.nvim_set_keymap("i", "<F1>", "<Nop>", { noremap = true, silent = true })
vim.api.nvim_set_keymap("v", "<F1>", "<Nop>", { noremap = true, silent = true })
