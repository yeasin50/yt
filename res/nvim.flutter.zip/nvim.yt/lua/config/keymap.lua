---  switch  to buffer
function _G.goto_buffer(n)
	local buffers = {}
	for _, buf in ipairs(vim.fn.getbufinfo({ buflisted = 1 })) do
		if vim.api.nvim_buf_is_loaded(buf.bufnr) then
			table.insert(buffers, buf.bufnr)
		end
	end
	if n <= #buffers then
		vim.api.nvim_set_current_buf(buffers[n])
	end
end

-- mappings
for i = 1, 9 do
	vim.api.nvim_set_keymap(
		"n",
		"<M-" .. i .. ">",
		string.format([[<cmd>lua _G.goto_buffer(%d)<CR>]], i),
		{ noremap = true, silent = true }
	)
end

---  run specific file;  dart for hot-reload
local run = require("config.run_file")

vim.keymap.set("n", "<leader>r", run.fileRunner, {
	desc = "smart file runner",
})
