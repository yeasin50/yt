---  nvim/lua/config/run_file.lua
local M = {}

-- Dart (Flutter Reload)
function M.fileRunner()
	local ft = vim.bo.filetype

	if ft == "dart" then
		local terms = require("toggleterm.terminal").get_all()
		if #terms == 0 then
			vim.notify("⚠️ No terminal running", vim.log.levels.WARN)
			return
		end
		terms[1]:send("r\n")
		vim.notify("🔥 Sent hot reload to Flutter terminal")
	else
		vim.notify("❌ Unsupported filetype: " .. ft)
	end
end

return M
