return {
	"nvim-flutter/flutter-tools.nvim",
	dependencies = {
		"nvim-lua/plenary.nvim",
		"stevearc/dressing.nvim", -- optional UI enhancement
	},
	config = function()
		require("config.lsp.servers.flutter")
	end,
	ft = { "dart" },
}
