
return {
	"ibhagwan/fzf-lua",
	dependencies = { "echasnovski/mini.icons" }, -- or use your preferred icon plugin
	opts = {
		files = {
			ignore = {
				".*/%.flutter%-plugins$",
				".*/%.flutter%-plugins%-dependencies$",
				".*/%.dart_tool/.*",
				".*/build/.*",
				".*/%.pub/.*",
				".*/%.packages$",
				"*./example/*",
			},
		},
	},

	config = function(_, opts)
		local fzf = require("fzf-lua")
		fzf.setup(opts)

		vim.api.nvim_create_autocmd("VimEnter", {
			callback = function()
				fzf.register_ui_select({ silent = true })
			end,
		})
	end,

	keys = {
		{
			"<leader>ff",
			function()
				require("fzf-lua").files()
			end,
			desc = "Find Files in project directory",
		},
		{
			"<leader>fg",
			function()
				require("fzf-lua").live_grep()
			end,
			desc = "Find by grepping in project directory",
		},
		{
			"<leader>fc",
			function()
				require("fzf-lua").files({ cwd = vim.fn.stdpath("config") })
			end,
			desc = "Find in neovim configuration",
		},
		{
			"<leader>fh",
			function()
				require("fzf-lua").helptags()
			end,
			desc = "[F]ind [H]elp",
		},
		{
			"<leader>fk",
			function()
				require("fzf-lua").keymaps()
			end,
			desc = "[F]ind [K]eymaps",
		},
		{
			"<leader>fb",
			function()
				require("fzf-lua").builtin()
			end,
			desc = "[F]ind [B]uiltin FZF",
		},
		{
			"<leader>fw",
			function()
				local mode = vim.fn.mode()
				if mode == "v" or mode == "V" then
					require("fzf-lua").grep_visual()
				else
					require("fzf-lua").grep_cword()
				end
			end,
			desc = "[F]ind current word or visual selection",
		},
		{
			"<leader>fW",
			function()
				require("fzf-lua").grep_cWORD()
			end,
			desc = "[F]ind current [W]ORD",
		},
		{
			"<leader>fd",
			function()
				require("fzf-lua").diagnostics_document()
			end,
			desc = "[F]ind [D]iagnostics",
		},
		{
			"<leader>fr",
			function()
				require("fzf-lua").resume()
			end,
			desc = "[F]ind [R]esume",
		},
		{
			"<leader>fo",
			function()
				require("fzf-lua").oldfiles()
			end,
			desc = "[F]ind [O]ld Files",
		},
		{
			"<leader><leader>",
			function()
				require("fzf-lua").buffers()
			end,
			desc = "[,] Find existing buffers",
		},
		{
			"<leader>/",
			function()
				require("fzf-lua").lgrep_curbuf()
			end,
			desc = "[/] Live grep the current buffer",
		},
	},
}
