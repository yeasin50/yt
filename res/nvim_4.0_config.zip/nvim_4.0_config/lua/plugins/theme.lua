return {
	"folke/tokyonight.nvim",
	enabled = true,
	lazy = false,
	priority = 1000,
	opts = {
		style = "storm", -- Theme variant: "storm", "night", "moon", "day"
		transparent = false,
		styles = { sidebars = "transparent", floats = "transparent" },
	},
	config = function()
		vim.cmd("colorscheme tokyonight")
	end,
}
